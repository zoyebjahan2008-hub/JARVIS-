JARVIS AI Android-friendly PWA Demo

Contents: index.html, manifest.json, service worker, icon.

How to install on Android (requires hosting over HTTPS or localhost):
1. Upload this folder to a static HTTPS host (or open the existing demo via a suitable web host).
2. Open the hosted index.html in Chrome on Android.
3. Chrome menu (⋮) > Add to Home screen / Install app.
4. For voice input, allow microphone access when prompted.

This is a local demo, not a full AI service. Voice recognition support varies by browser; the app may need internet for browser speech recognition.
